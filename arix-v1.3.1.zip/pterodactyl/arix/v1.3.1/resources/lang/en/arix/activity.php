<?php

return [
    'account-activity-log' => 'Account Activity Log',
    'activity-log' => 'Activity Log',
    'clear-filters' => 'Clear Filters',
    'metadata' => 'Metadata',
    'close' => 'Close',
    'no-logs-server' => 'No activity logs available for this server.'
];